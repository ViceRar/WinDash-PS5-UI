import os
os.startfile(r"C:\WinDash\Game Files\<Game.exe>")